from BCC_HTCS.BTI2 import BTTC

BTTC()


