from BCC_HTCS.BTI import BTTC

BTTC(iteration=5)


